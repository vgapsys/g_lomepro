

echo -e 2 3 | ../g_lomepro_static -s popc_pops_membrane.pdb -f popc_pops_membrane.xtc -n popc_pops_membrane.ndx -binx 50 -biny 50 -lipGroup_num 2 -lip_num "58 230" -apl -dens -thick

