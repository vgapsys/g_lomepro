
# create folder
mkdir split_frames

# split frames 
perl split_pdb_Bfact_CMD.pl -i mov_pdb.pdb_thickness.pdb -o split_frames/frame

# render with pymol
perl render.pl 

# merge into a movie
ffmpeg -r 30 -f image2 -s 1920x1080 -start_number 0 -i split_frames/out_%d.png -vframes 11 -vcodec libx264 -crf 25  -pix_fmt yuv420p movie.mp4

