use strict;
use warnings;
use Cwd;

my $base = getcwd;

for(my $i=0; $i<=10; $i++)
{
	print "Rendering $i\n";
	my $frname = "$base/split_frames/frame_$i.pdb";
	my $outname = "$base/split_frames/out_$i.png";

	system("pymol -qc -d \'load $frname, fr; \@pml.pml; ray 1024, 768; png $outname, 1024, dpi=150; quit\'");
}

